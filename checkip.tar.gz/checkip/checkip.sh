	userDir=$HOME/checkip
	dataDir=$HOME/checkip/data
	logDir=$HOME/checkip/log	
	read ipOld < $dataDir/ipold.txt	
	
	wget www.icanhazip.com
	mv index.html $dataDir
	read ipNew < $dataDir/index.html
	
	if [ "$ipOld" = "$ipNew" ] 
	then
		date=`date`		
		log="$date -- IP adress $ipNew did not change -- no notification send"		
		echo $log >> $logDir/log.txt

	else
		date=`date`
		emailTo="merlijnschoots@gmail.com"		
		
		log=$date" -- IP adress $ipNew has changed -- email notification send to $emailTo"		
		echo $log >> $logDir/log.txt
	
		echo "Subject:IP adres $USER is veranderd" >> temp
		echo "Het nieuwe IP adres van $USER is veranderd van $ipOld naar $ipNew" >> temp 
		sendmail merlijnschoots@gmail.com < temp 
		
		rm temp
		echo $ipNew > $dataDir/ipold.txt
	fi
