#!/bin/bash

# dynamic-ip-notifier shell script
# this script will inquire the system external IP adress and compare it to the last but one IP query

# set global vars
userDir=$HOME/ip-notifier
dataDir=$HOME/ip-notifier/data
logDir=$HOME/ip-notifier/log	
configDir=$HOME/ip-notifier/config

# read last but one IP adress from file to var
read ipOld < $dataDir/ip.old	

# inquire recent external IP adress from http://www.icanhazip.com
wget http://www.icanhazip.com

# move downloadend index.html from http://www.icanhazip.com to $dataDir
mv index.html $dataDir

# read recent IP adress from file to var
read ipNew < $dataDir/index.html

# compare recent IP adress to last but one IP adress	
if [ "$ipOld" = "$ipNew" ] 
then
	# IP status quo logged to logfile
	date=`date`		
	log="$date -- IP adress $ipNew did not change -- no notification send"		
	echo $log >> $logDir/history.log

else
	# email recipient read from config.ini to var
	read emailTo < $configDir/config.ini
	
	# IP change logged to logfile	
	date=`date`
	log=$date" -- IP adress $ipNew has changed -- email notification send to $emailTo"		
	echo $log >> $logDir/history.log
	
	# IP change send to recipient
	echo "Subject:IP adres $USER is veranderd" >> temp
	echo "Het nieuwe IP adres van $USER is veranderd van $ipOld naar $ipNew" >> temp 
	sendmail merlijnschoots@gmail.com < temp 
	rm temp
	
	# recent IP set as ip.old	
	echo $ipNew > $dataDir/ip.old
fi
